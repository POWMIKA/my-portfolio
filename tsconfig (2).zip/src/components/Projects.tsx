"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const chipColors = [
  { bg: "#e3ecff", text: "#3556b8", dot: "#4d7cfe" },
  { bg: "#ece4ff", text: "#6a4fc4", dot: "#8b6cf0" },
  { bg: "#ddf5e8", text: "#2a7a55", dot: "#3fb37f" },
  { bg: "#fff0d6", text: "#a8650f", dot: "#f0a431" },
  { bg: "#ffe3ea", text: "#b3395a", dot: "#f06a8e" },
  { bg: "#dcf3fb", text: "#1f7894", dot: "#35b4d8" },
];

const projects = [
  {
    title: "SemiconMart",
    category: "B2B Semiconductor Platform",
    description:
      "A technology-driven platform for semiconductor procurement, sourcing and supply-chain operations.",
    details:
      "SemiconMart is a B2B marketplace that connects buyers and suppliers in the semiconductor industry. I built the Phase 1 frontend, focusing on a clean, responsive interface for browsing components, sourcing and procurement enquiries.",
    features: [
      "Responsive B2B storefront for semiconductor sourcing",
      "Smooth animated interface built with Framer Motion",
      "Enquiry and contact flow using NodeMailer",
    ],
    tech: [
      "Next.js",
      "TypeScript",
      "React",
      "Node.js",
      "Tailwind CSS",
      "Framer Motion",
      "NodeMailer",
    ],
    image: "/images/projects/semiconmart-site.png",
    logo: "/images/projects/semiconmart-logo.png",
    link: "https://semiconmart.io/",
    linkText: "Visit website",
    accent: "#4d7cfe",
    soft: "#edf2ff",
    gradient:
      "linear-gradient(135deg, #d6e2ff 0%, #e8eeff 55%, #efe6ff 100%)",
    glow: "#b7c9ff",
  },
  {
    title: "WintenseCare",
    category: "Real-Time Healthcare Platform",
    description:
      "A real-time wearable health monitoring platform with live dashboards, telemetry and ECG visualization.",
    details:
      "WintenseCare is a real-time patient monitoring platform that receives data from connected wearable medical devices and shows it live to care teams. It is currently in development.",
    features: [
      "Live patient dashboards with real-time telemetry",
      "ECG waveform visualization over WebSockets",
      "REST APIs integrated with wearable device data",
    ],
    tech: [
      "React",
      "Next.js",
      "Node.js",
      "TypeScript",
      "PostgreSQL",
      "WebSockets",
      "RESTful APIs",
      "Docker",
      "Kubernetes",
    ],
    image: "/images/projects/wintensecare-site.png",
    logo: "/images/projects/wintensecare-logo.png",
    link: "#",
    linkText: "In development",
    accent: "#3f9d70",
    soft: "#e8f6ee",
    gradient:
      "linear-gradient(135deg, #cdeedb 0%, #e5f5ec 55%, #dcf3fb 100%)",
    glow: "#b4e4c8",
  },
  {
    title: "Itonus",
    category: "MERN Stack Web Application",
    description:
      "A full-stack web application with authentication and responsive interfaces.",
    details:
      "Itonus is a full-stack web application built on the MERN stack. It includes user authentication, a REST API backend and responsive interfaces that work across desktop and mobile.",
    features: [
      "User authentication and protected routes",
      "REST API with Express and MongoDB",
      "Fully responsive React interface",
    ],
    tech: ["MongoDB", "Express", "React", "Node.js"],
    image: "/images/projects/itonus-site.png",
    logo: "/images/projects/itonus-logo.webp",
    link: "https://www.itonus.co.in/",
    linkText: "Visit website",
    accent: "#8466c4",
    soft: "#f3edfb",
    gradient:
      "linear-gradient(135deg, #e6dbf8 0%, #f3edfb 55%, #fde9ee 100%)",
    glow: "#d9c3f2",
  },
  {
    title: "Prasiddhi Vidyodaya",
    category: "School Website",
    description:
      "A responsive school website presenting academics, activities and announcements.",
    details:
      "A modern website for Prasiddhi Vidyodaya school that presents academics, activities, announcements and institutional information to parents and students, with a Node.js and MongoDB backend.",
    features: [
      "Clear sections for academics, activities and announcements",
      "Responsive layout for parents on mobile devices",
      "Express and MongoDB backend for dynamic content",
    ],
    tech: ["Next.js", "React", "Tailwind CSS", "Express", "Node.js", "MongoDB"],
    image: "/images/projects/prasiddhi-site.png",
    logo: "/images/projects/prasiddhi-logo.png",
    link: "https://www.prasiddhividyodaya.com/",
    linkText: "Visit website",
    accent: "#d0883f",
    soft: "#fff3e3",
    gradient:
      "linear-gradient(135deg, #ffe6c7 0%, #fff3e3 55%, #ffe3ea 100%)",
    glow: "#ffd3a1",
  },
];

export default function Projects() {
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const selected = selectedIndex === null ? null : projects[selectedIndex];

  useEffect(() => {
    if (selectedIndex === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelectedIndex(null);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [selectedIndex]);

  return (
    <section
      id="projects"
      className="relative overflow-hidden bg-[#faf8f4] px-5 py-16 sm:px-8 md:py-20"
    >
      {/* Background glow */}
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 top-32 h-64 w-64 rounded-full bg-[#e4dcf7]/70 blur-3xl"
        animate={{ x: [0, 25, 0], y: [0, -20, 0], scale: [1, 1.12, 1] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="relative mx-auto max-w-5xl">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 22 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex items-center gap-3">
            <motion.span
              initial={{ width: 0 }}
              whileInView={{ width: 32 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="h-px bg-[#8966b9]"
            />
            <p className="text-xs font-semibold uppercase tracking-[0.17em] text-[#8063ad]">
              04 / Selected Work
            </p>
          </div>

          <h2 className="mt-4 text-3xl font-medium tracking-[-0.045em] text-[#172033] sm:text-4xl md:text-[2.8rem]">
            Things I&apos;ve{" "}
            <motion.span
              className="inline-block text-[#8063ad]"
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}
            >
              built.
            </motion.span>
          </h2>

          <p className="mt-3 max-w-xl text-sm leading-6 text-[#667087] sm:text-base">
            Products and platforms I have contributed to across web development
            and connected systems.
          </p>
        </motion.div>

        {/* Project grid */}
        <div className="mt-9 grid gap-5 md:grid-cols-2">
          {projects.map((project, index) => {
            const host =
              project.link !== "#"
                ? new URL(project.link).hostname.replace("www.", "")
                : "in development";

            return (
              <motion.article
                key={project.title}
                initial={{ opacity: 0, y: 40, scale: 0.97 }}
                whileInView={{ opacity: 1, y: 0, scale: 1 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.65,
                  delay: (index % 2) * 0.12,
                  ease: [0.22, 1, 0.36, 1],
                }}
                whileHover={{ y: -6 }}
                className="group relative isolate flex flex-col overflow-hidden rounded-2xl border border-white/70 p-4 shadow-[0_6px_24px_rgba(36,48,85,0.06)] transition-shadow duration-300 hover:shadow-[0_16px_36px_rgba(36,48,85,0.14)] sm:p-5"
                style={{ background: project.gradient }}
              >
                {/* Top accent bar that grows on hover */}
                <span
                  className="absolute left-0 top-0 h-1 w-1/4 transition-all duration-700 group-hover:w-full"
                  style={{ backgroundColor: project.accent }}
                />

                {/* Moving glow */}
                <motion.div
                  aria-hidden="true"
                  className="pointer-events-none absolute -right-14 -top-16 -z-10 h-44 w-44 rounded-full blur-2xl"
                  style={{ backgroundColor: project.glow, opacity: 0.6 }}
                  animate={{ x: [0, -14, 0], y: [0, 12, 0], scale: [1, 1.15, 1] }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: index * 0.8,
                  }}
                />

                {/* Browser frame with website screenshot */}
                <div className="overflow-hidden rounded-xl border border-white/80 bg-white shadow-sm">
                  <div className="flex items-center gap-1.5 border-b border-black/5 bg-white px-3 py-2">
                    <span className="h-2 w-2 rounded-full bg-[#ff6b6b]" />
                    <span className="h-2 w-2 rounded-full bg-[#ffc94d]" />
                    <span className="h-2 w-2 rounded-full bg-[#4cd08a]" />
                    <span className="ml-2 truncate rounded-full bg-[#f2f4f8] px-3 py-0.5 text-[10px] text-[#8790a1]">
                      {host}
                    </span>
                  </div>

                  <div className="relative h-44 overflow-hidden bg-[#f2f4f8] sm:h-48">
                    <Image
                      src={project.image}
                      alt={`${project.title} website`}
                      fill
                      sizes="(max-width: 768px) 100vw, 50vw"
                      className="object-cover object-top transition-[object-position] duration-[4000ms] ease-in-out group-hover:object-bottom"
                    />
                  </div>
                </div>

                {/* Title row with logo */}
                <div className="mt-4 flex items-center gap-3">
                  <motion.div
                    whileHover={{ rotate: 6, scale: 1.1 }}
                    transition={{ type: "spring", stiffness: 300 }}
                    className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white p-1.5 shadow-sm"
                    style={{ boxShadow: `0 0 0 2px ${project.accent}40` }}
                  >
                    <Image
                      src={project.logo}
                      alt={`${project.title} logo`}
                      width={36}
                      height={36}
                      className="h-full w-full object-contain"
                    />
                  </motion.div>

                  <div className="min-w-0">
                    <h3 className="truncate text-xl font-semibold tracking-tight text-[#172033]">
                      {project.title}
                    </h3>
                    <p
                      className="text-[11px] font-semibold uppercase tracking-[0.1em]"
                      style={{ color: project.accent }}
                    >
                      {project.category}
                    </p>
                  </div>
                </div>

                <p className="mt-3 line-clamp-2 text-sm leading-6 text-[#4f5b72]">
                  {project.description}
                </p>

                {/* Tech preview */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {project.tech.slice(0, 4).map((t) => (
                    <span
                      key={t}
                      className="rounded-full bg-white/70 px-2.5 py-1 text-[10px] font-medium text-[#596579] ring-1 ring-white"
                    >
                      {t}
                    </span>
                  ))}
                  {project.tech.length > 4 && (
                    <span
                      className="rounded-full px-2.5 py-1 text-[10px] font-semibold"
                      style={{
                        backgroundColor: `${project.accent}20`,
                        color: project.accent,
                      }}
                    >
                      +{project.tech.length - 4} more
                    </span>
                  )}
                </div>

                {/* Buttons */}
                <div className="mt-auto flex flex-wrap items-center gap-2 pt-5">
                  <button
                    type="button"
                    onClick={() => setSelectedIndex(index)}
                    className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold text-white transition-all duration-300 hover:gap-3"
                    style={{ backgroundColor: project.accent }}
                  >
                    View details <span aria-hidden="true">→</span>
                  </button>

                  {project.link !== "#" ? (
                    <a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 rounded-full bg-white/70 px-4 py-2 text-sm font-semibold ring-1 transition hover:bg-white"
                      style={{ color: project.accent }}
                    >
                      Visit website
                      <ArrowUpRight size={15} />
                    </a>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-white/50 px-4 py-2 text-sm font-medium text-[#8790a1]">
                      In development
                    </span>
                  )}
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>

      {/* Details popup */}
      <AnimatePresence>
        {selected && (
          <motion.div
            key="project-modal"
            className="fixed inset-0 z-[100] flex items-center justify-center overflow-y-auto bg-[#11182a]/55 p-4 backdrop-blur-sm sm:p-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={(e) => {
              if (e.target === e.currentTarget) setSelectedIndex(null);
            }}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="project-modal-title"
              initial={{ opacity: 0, y: 24, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.97 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="relative my-auto max-h-[88vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-white/80 bg-white shadow-2xl"
            >
              {/* Header */}
              <div
                className="relative px-6 py-6 sm:px-8"
                style={{ background: selected.gradient }}
              >
                <div className="flex items-center gap-4 pr-10">
                  <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-white p-2 shadow-sm">
                    <Image
                      src={selected.logo}
                      alt={`${selected.title} logo`}
                      width={44}
                      height={44}
                      className="h-full w-full object-contain"
                    />
                  </div>
                  <div>
                    <p
                      className="text-xs font-semibold uppercase tracking-[0.14em]"
                      style={{ color: selected.accent }}
                    >
                      {selected.category}
                    </p>
                    <h3
                      id="project-modal-title"
                      className="mt-1 text-2xl font-semibold tracking-[-0.03em] text-[#172033] sm:text-3xl"
                    >
                      {selected.title}
                    </h3>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedIndex(null)}
                  aria-label="Close project details"
                  className="absolute right-5 top-5 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 text-xl text-[#354057] transition hover:rotate-90 hover:bg-white"
                >
                  ×
                </button>
              </div>

              {/* Body */}
              <div
                className="space-y-6 px-6 py-6 sm:px-8"
                style={{
                  background: `linear-gradient(180deg, ${selected.soft} 0%, #ffffff 60%)`,
                }}
              >
                <div className="relative h-52 overflow-hidden rounded-xl shadow-md ring-4 ring-white sm:h-60">
                  <Image
                    src={selected.image}
                    alt={`${selected.title} website`}
                    fill
                    sizes="(max-width: 768px) 100vw, 640px"
                    className="object-cover object-top"
                  />
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-[0.15em] text-[#8790a1]">
                    About the project
                  </h4>
                  <p className="mt-3 text-sm leading-7 text-[#536078]">
                    {selected.details}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-[0.15em] text-[#8790a1]">
                    Key features
                  </h4>
                  <ul className="mt-3 space-y-2.5">
                    {selected.features.map((f, i) => (
                      <motion.li
                        key={f}
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.07 }}
                        className="flex items-start gap-3 text-sm leading-6 text-[#45516a]"
                      >
                        <span
                          className="mt-2 h-2 w-2 shrink-0 rounded-full"
                          style={{ backgroundColor: selected.accent }}
                        />
                        <span>{f}</span>
                      </motion.li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-[0.15em] text-[#8790a1]">
                    Technologies used
                  </h4>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {selected.tech.map((t, i) => {
                      const c = chipColors[i % chipColors.length];
                      return (
                        <motion.span
                          key={t}
                          initial={{ opacity: 0, y: 8, scale: 0.9 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          transition={{ delay: 0.2 + i * 0.04 }}
                          whileHover={{ y: -3, scale: 1.06 }}
                          className="inline-flex items-center gap-2 rounded-full px-3.5 py-1.5 text-xs font-semibold shadow-sm ring-1 ring-white"
                          style={{ backgroundColor: c.bg, color: c.text }}
                        >
                          <span
                            className="h-1.5 w-1.5 rounded-full"
                            style={{ backgroundColor: c.dot }}
                          />
                          {t}
                        </motion.span>
                      );
                    })}
                  </div>
                </div>

                <div className="flex flex-wrap justify-end gap-2 border-t border-[#e8e8ed] pt-5">
                  <button
                    type="button"
                    onClick={() => setSelectedIndex(null)}
                    className="rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-[#45516a] ring-1 ring-[#e1e4ec] transition hover:bg-[#f6f7fa]"
                  >
                    Close
                  </button>

                  {selected.link !== "#" ? (
                    <a
                      href={selected.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold text-white transition hover:opacity-85"
                      style={{ backgroundColor: selected.accent }}
                    >
                      Visit website
                      <ArrowUpRight size={15} />
                    </a>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-[#eef0f5] px-5 py-2.5 text-sm font-medium text-[#8790a1]">
                      In development
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}