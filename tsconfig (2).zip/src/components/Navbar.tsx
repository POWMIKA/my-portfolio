"use client";

import { useState } from "react";
import { Menu, X } from "lucide-react";

const navItems = [
  { name: "About", href: "#about" },
  { name: "Experience", href: "#experience" },
  { name: "Projects", href: "#projects" },
  { name: "Skills", href: "#skills" },
  { name: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed left-0 right-0 top-0 z-50 bg-[#f7f7f5]/90 backdrop-blur-sm">
      <div className="mx-auto flex h-20 max-w-[1400px] items-center justify-between border-b border-black/10 px-6 lg:px-10">

        {/* Logo */}
        <a
          href="#home"
          className="text-sm font-semibold tracking-[0.18em]"
        >
          KALAIPOWMIKA K
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-8 md:flex">
          {navItems.map((item) => (
            <a
              key={item.name}
              href={item.href}
              className="text-xs uppercase tracking-[0.14em] text-black/60 transition-colors duration-300 hover:text-black"
            >
              {item.name}
            </a>
          ))}
        </nav>

        {/* Resume */}
        <a
          href="/resume.pdf"
          className="hidden text-xs uppercase tracking-[0.14em] underline underline-offset-4 md:block"
        >
          Resume
        </a>

        {/* Mobile button */}
        <button
          onClick={() => setOpen(!open)}
          className="md:hidden"
          aria-label="Toggle navigation"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="border-b border-black/10 bg-[#f7f7f5] px-6 py-8 md:hidden">
          <nav className="flex flex-col gap-6">
            {navItems.map((item) => (
              <a
                key={item.name}
                href={item.href}
                onClick={() => setOpen(false)}
                className="text-sm uppercase tracking-[0.14em]"
              >
                {item.name}
              </a>
            ))}

            <a
              href="/resume.pdf"
              className="text-sm uppercase tracking-[0.14em] underline underline-offset-4"
            >
              Resume
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}