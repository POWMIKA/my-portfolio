import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Education from "@/components/Education";
import Experience from "@/components/Experience";
import Projects from "@/components/Projects";

export default function Home() {
  return (
    <main className="bg-[#f7f7f5]">
      <Navbar />
      <Hero />
      <About />
      <Education />
      <Experience />
      <Projects />
      <section
        id="about"
        className="min-h-screen px-6 py-32 lg:px-10"
      >
        <div className="mx-auto max-w-[1400px]">
          <p className="text-xs uppercase tracking-[0.18em] text-black/40">
            01 / About
          </p>

          <h2 className="mt-8 max-w-4xl text-5xl font-medium tracking-[-0.04em] md:text-7xl">
            Building useful software with a focus on clarity,
            performance and user experience.
          </h2>
        </div>
      </section>

      <section
        id="projects"
        className="min-h-screen bg-[#111] px-6 py-32 text-white lg:px-10"
      >
        <div className="mx-auto max-w-[1400px]">
          <p className="text-xs uppercase tracking-[0.18em] text-white/40">
            02 / Selected Work
          </p>

          <h2 className="mt-8 text-5xl font-medium tracking-[-0.04em] md:text-7xl">
            Selected Projects
          </h2>
        </div>
      </section>
    </main>
  );
}