"use client";

import Image from "next/image";
import { motion } from "framer-motion";

const education = [
  {
    type: "Higher Education",
    name: "National Institute of Technology Puducherry",
    location: "Karaikal, Puducherry",
    period: "2020 — 2024",
    description: "B.Tech — Computer Science & Engineering",
    image: "/images/education/college.webp",
    logo: "/images/education/college-logo.png",
    bg: "bg-[#eef5ff]",
    accent: "text-[#4d7cfe]",
  },
  {
    type: "School Education",
    name: "Amalorpavam Higher Secondary School",
    location: "Puducherry",
    period: "LKG — XII",
    description: "School education completed from LKG through Class XII.",
    image: "/images/education/school.jpeg",
    logo: "/images/education/school-logo.png",
    bg: "bg-[#f1f8f2]",
    accent: "text-[#5b9b72]",
  },
];

export default function Education() {
  return (
    <section
      id="education"
      className="relative overflow-hidden bg-[#f8f6f1] px-6 py-28 lg:px-10 lg:py-36"
    >
      {/* Decorative moving shape */}
      <motion.div
        animate={{
          x: [0, 30, 0],
          y: [0, -20, 0],
          rotate: [0, 4, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="pointer-events-none absolute right-[8%] top-20 h-32 w-32 rounded-full bg-[#dcecff] opacity-60 blur-2xl"
      />

      <div className="relative mx-auto max-w-[1400px]">

        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-xs uppercase tracking-[0.18em] text-[#4d7cfe]">
            02 / Education
          </p>

          <h2 className="mt-8 max-w-4xl text-5xl font-medium leading-[1] tracking-[-0.04em] text-[#172033] md:text-7xl">
            The foundation behind my{" "}
            <motion.span
              animate={{
                y: [0, -5, 0],
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="inline-block text-[#4d7cfe]"
            >
              journey.
            </motion.span>
          </h2>
        </motion.div>

        {/* Education */}
        <div className="mt-20 space-y-10">

          {education.map((item, index) => (
            <motion.article
              key={item.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.7,
                delay: index * 0.15,
              }}
              whileHover={{ y: -6 }}
              className={`group relative overflow-hidden rounded-[2rem] ${item.bg} p-7 transition-shadow duration-500 hover:shadow-xl md:p-10 lg:p-12`}
            >

              {/* Small animated circle */}
              <motion.div
                animate={{
                  scale: [1, 1.15, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-white/50"
              />

              <div className="relative grid gap-10 lg:grid-cols-[0.3fr_1fr]">

                {/* Left */}
                <div>
                  <p
                    className={`text-xs uppercase tracking-[0.18em] ${item.accent}`}
                  >
                    {item.type}
                  </p>

                  <motion.p
                    initial={{ opacity: 0, x: -15 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.25 }}
                    className="mt-6 text-sm font-medium text-[#596579]"
                  >
                    {item.period}
                  </motion.p>

                  <p className="mt-2 text-sm text-[#718096]">
                    {item.location}
                  </p>
                </div>

                {/* Right */}
                <div className="grid items-center gap-8 md:grid-cols-[1fr_260px]">

                  <div>
                    {/* Logo */}
                    <motion.div
                      whileHover={{
                        rotate: -4,
                        scale: 1.06,
                      }}
                      transition={{
                        type: "spring",
                        stiffness: 300,
                      }}
                      className="mb-7 flex h-16 w-16 items-center justify-center rounded-2xl border border-white/80 bg-white/80 p-2 shadow-sm"
                    >
                      <Image
                        src={item.logo}
                        alt={`${item.name} logo`}
                        width={56}
                        height={56}
                        className="h-full w-full object-contain"
                      />
                    </motion.div>

                    <h3 className="max-w-3xl text-3xl font-medium tracking-[-0.03em] text-[#172033] md:text-4xl">
                      {item.name}
                    </h3>

                    <p className="mt-4 text-lg text-[#596579]">
                      {item.description}
                    </p>
                  </div>

                  {/* Image */}
                  <motion.div
                    whileHover={{ scale: 1.03 }}
                    transition={{ duration: 0.5 }}
                    className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-white/80 bg-white/50 shadow-sm"
                  >
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="260px"
                    />
                  </motion.div>

                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}