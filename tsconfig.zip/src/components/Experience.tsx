"use client";

import Image from "next/image";
import { motion } from "framer-motion";

const experiences = [
  {
    role: "Software Engineer",
    company: "DIKITE Pvt Ltd",
    period: "Oct 2025 — Present",
    location: "Chennai, Tamil Nadu, India · On-site",
    logo: "/images/experience/dikite-logo.webp",
    bg: "bg-[#edf3ff]",
    accent: "text-[#4d7cfe]",
  },
  {
    role: "Data Analyst",
    company: "Straive",
    period: "Jun 2025 — Oct 2025",
    location: "Chennai, Tamil Nadu, India · On-site",
    logo: "/images/experience/straive-logo.webp",
    bg: "bg-[#f3effb]",
    accent: "text-[#8a6bbd]",
  },
];

export default function Experience() {
  return (
    <section
      id="experience"
      className="relative overflow-hidden bg-[#f3f7fb] px-6 py-28 lg:px-10 lg:py-36"
    >
      {/* Floating decoration */}
      <motion.div
        animate={{
          x: [0, -25, 0],
          y: [0, 20, 0],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="pointer-events-none absolute left-[5%] top-24 h-36 w-36 rounded-full bg-[#e4dcf7] opacity-50 blur-3xl"
      />

      <div className="relative mx-auto max-w-[1400px]">

        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-xs uppercase tracking-[0.18em] text-[#6d82b8]">
            04 / Experience
          </p>

          <h2 className="mt-8 max-w-5xl text-5xl font-medium leading-[1] tracking-[-0.04em] text-[#172033] md:text-7xl">
            Professional{" "}
            <motion.span
              animate={{
                x: [0, 8, 0],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="inline-block text-[#6d82b8]"
            >
              experience.
            </motion.span>
          </h2>

          <p className="mt-6 max-w-2xl text-base leading-7 text-[#596579] md:text-lg">
            Experience across software engineering, web development and data
            analysis.
          </p>
        </motion.div>

        {/* Experience list */}
        <div className="mt-20 space-y-6">

          {experiences.map((experience, index) => (
            <motion.article
              key={experience.company}
              initial={{
                opacity: 0,
                x: index % 2 === 0 ? -40 : 40,
              }}
              whileInView={{
                opacity: 1,
                x: 0,
              }}
              viewport={{
                once: true,
                amount: 0.2,
              }}
              transition={{
                duration: 0.7,
                delay: index * 0.15,
              }}
              whileHover={{
                y: -5,
              }}
              className={`group relative overflow-hidden rounded-[1.75rem] ${experience.bg} p-7 transition-shadow duration-500 hover:shadow-lg md:p-9`}
            >

              {/* Moving decorative circle */}
              <motion.div
                animate={{
                  x: [0, 15, 0],
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute -right-16 -top-16 h-44 w-44 rounded-full bg-white/50"
              />

              <div className="relative grid gap-8 md:grid-cols-[170px_1fr_auto] md:items-center">

                {/* Period */}
                <div>
                  <p className="text-sm font-medium text-[#596579]">
                    {experience.period}
                  </p>
                </div>

                {/* Company */}
                <div className="flex items-center gap-5">

                  {/* Logo */}
                  <motion.div
                    whileHover={{
                      rotate: 5,
                      scale: 1.08,
                    }}
                    transition={{
                      type: "spring",
                      stiffness: 300,
                    }}
                    className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl border border-white/80 bg-white/80 p-3 shadow-sm"
                  >
                    <Image
                      src={experience.logo}
                      alt={`${experience.company} logo`}
                      width={48}
                      height={48}
                      className="h-full w-full object-contain"
                    />
                  </motion.div>

                  <div>
                    <h3 className="text-2xl font-medium tracking-[-0.02em] text-[#172033] md:text-3xl">
                      {experience.role}
                    </h3>

                    <motion.p
                      whileHover={{ x: 4 }}
                      className={`mt-2 text-base font-medium ${experience.accent}`}
                    >
                      {experience.company}
                    </motion.p>

                    <p className="mt-1 text-sm text-[#718096]">
                      {experience.location}
                    </p>
                  </div>
                </div>

                {/* Number */}
                <motion.div
                  animate={{
                    y: [0, -4, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: index * 0.5,
                    ease: "easeInOut",
                  }}
                  className="hidden text-sm font-medium text-[#9aa6b8] md:block"
                >
                  0{index + 1}
                </motion.div>

              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}