"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";

const projects = [
  {
    number: "01",
    title: "SemiconMart",
    category: "B2B Semiconductor Platform",
    description:
      "A technology-driven platform for semiconductor procurement, sourcing and supply-chain operations.",
    tech: [
      "Next.js",
      "TypeScript",
      "React",
      "Node.js",
      "Tailwind CSS",
      "Framer Motion",
      "NodeMailer",
    ],
    image: "/images/projects/semiconmart.png",
    link: "https://semiconmart.io/",
    linkText: "Visit website",
    background: "bg-[#eaf3ff]",
    accent: "text-[#4d7cfe]",
  },

  {
    number: "02",
    title: "WintenseCare",
    category: "Real-Time Healthcare Platform",
    description:
      "A real-time wearable health monitoring platform with live dashboards, telemetry, ECG visualization and connected device data.",
    tech: [
      "React",
      "Next.js",
      "Node.js",
      "TypeScript",
      "PostgreSQL",
      "WebSockets",
      "RESTful APIs",
      "Docker",
      "Kubernetes",
    ],
    image: "/images/projects/wintensecare.webp",
    link: "#",
    linkText: "In development",
    background: "bg-[#eef8f1]",
    accent: "text-[#57946d]",
  },

  {
    number: "03",
    title: "Itonus",
    category: "MERN Stack Web Application",
    description:
      "A full-stack web application built with MongoDB, Express, React and Node.js with authentication and responsive interfaces.",
    tech: [
      "MongoDB",
      "Express",
      "React",
      "Node.js",
    ],
    image: "/images/projects/itonus.webp",
    link: "https://www.itonus.co.in/",
    linkText: "Visit website",
    background: "bg-[#f4effb]",
    accent: "text-[#8768b8]",
  },

  {
    number: "04",
    title: "Prasiddhi Vidyodaya",
    category: "School Website",
    description:
      "A modern responsive school website designed to present academics, activities, announcements and institutional information.",
    tech: [
      "Next.js",
      "React",
      "Tailwind CSS",
      "Express",
      "Node.js",
      "MongoDB",
    ],
    image: "/images/projects/prasiddhi.png",
    link: "https://www.prasiddhividyodaya.com/",
    linkText: "Visit website",
    background: "bg-[#fff3e8]",
    accent: "text-[#c98250]",
  },
];

export default function Projects() {
  return (
    <section
      id="projects"
      className="relative overflow-hidden bg-[#faf8f4] px-6 py-24 lg:px-10 lg:py-32"
    >
      <div className="mx-auto max-w-[1400px]">

        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.7 }}
        >
          <p className="text-xs uppercase tracking-[0.18em] text-[#6d82b8]">
            05 / Selected Work
          </p>

          <h2 className="mt-7 max-w-5xl text-5xl font-medium leading-[1] tracking-[-0.05em] text-[#172033] md:text-7xl">
            Things I&apos;ve{" "}
            <motion.span
              animate={{
                y: [0, -5, 0],
              }}
              transition={{
                duration: 2.8,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="inline-block text-[#6d82b8]"
            >
              built.
            </motion.span>
          </h2>

          <p className="mt-6 max-w-2xl text-base leading-7 text-[#596579] md:text-lg">
            A selection of products, platforms and applications I have
            contributed to across web development and connected systems.
          </p>
        </motion.div>

        {/* 2 × 2 PROJECT GRID */}
        <div className="mt-16 grid gap-6 md:grid-cols-2">

          {projects.map((project, index) => (
            <motion.article
              key={project.title}
              initial={{
                opacity: 0,
                y: 40,
              }}
              whileInView={{
                opacity: 1,
                y: 0,
              }}
              viewport={{
                once: true,
                amount: 0.15,
              }}
              transition={{
                duration: 0.7,
                delay: index * 0.1,
              }}
              whileHover={{
                y: -6,
              }}
              className={`group relative overflow-hidden rounded-[1.75rem] ${project.background} p-5 transition-shadow duration-500 hover:shadow-xl md:p-6`}
            >

              {/* Decorative moving shape */}
              <motion.div
                animate={{
                  x: [0, 15, 0],
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 7,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-white/50"
              />

              <div className="relative">

                {/* Project image — compact 4:2 style */}
                <motion.div
                  whileHover={{
                    scale: 1.02,
                  }}
                  transition={{
                    duration: 0.45,
                  }}
                  className="relative aspect-[2/1] overflow-hidden rounded-[1.25rem] border border-white/80 bg-white/60 shadow-sm"
                >
                  <Image
                    src={project.image}
                    alt={`${project.title} project`}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-[1.04]"
                    sizes="(max-width: 768px) 100vw, 50vw"
                  />
                </motion.div>

                {/* Project information */}
                <div className="relative mt-6">

                  {/* Number + category */}
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-medium tracking-[0.15em] text-[#8b95a5]">
                      {project.number}
                    </span>

                    <span className="h-px w-7 bg-[#b7c0cc]" />

                    <span
                      className={`text-[10px] uppercase tracking-[0.13em] ${project.accent}`}
                    >
                      {project.category}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="mt-4 text-3xl font-medium tracking-[-0.04em] text-[#172033]">
                    {project.title}
                  </h3>

                  {/* Description */}
                  <p className="mt-3 text-sm leading-6 text-[#596579]">
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="mt-5 flex flex-wrap gap-1.5">
                    {project.tech.map((technology) => (
                      <span
                        key={technology}
                        className="rounded-full border border-black/10 bg-white/60 px-2.5 py-1 text-[10px] text-[#596579]"
                      >
                        {technology}
                      </span>
                    ))}
                  </div>

                  {/* Website */}
                  {project.link !== "#" ? (
                    <motion.a
                      href={project.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      whileHover={{ x: 4 }}
                      className={`mt-6 inline-flex items-center gap-2 text-sm font-medium ${project.accent}`}
                    >
                      {project.linkText}
                      <ArrowUpRight size={15} />
                    </motion.a>
                  ) : (
                    <span
                      className={`mt-6 inline-flex text-sm font-medium ${project.accent}`}
                    >
                      {project.linkText}
                    </span>
                  )}
                </div>
              </div>
            </motion.article>
          ))}

        </div>
      </div>
    </section>
  );
}